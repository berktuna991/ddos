#pragma once

#define HTTP_SERVER "162.216.114.40"
#define HTTP_PORT 80

#define TFTP_SERVER "162.216.114.40"
